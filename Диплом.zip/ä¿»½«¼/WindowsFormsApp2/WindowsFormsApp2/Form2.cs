﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormAddServices : Form
    {
        private SqlConnection SqlConnection = null;
        SqlCommand servicesCommand;
        SqlDataAdapter servicesAdapter;
        DataSet servicesDataset;
        DataTable servicesTable;

        public FormAddServices()
        {
            InitializeComponent();
        }
        private void FormAddServices_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Services"].ConnectionString);
            SqlConnection.Open();
        }

        //Добавление новой записи
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand($"insert into [Services] (id_service, service_name, service_price, service_desc) values (@id_service, @service_name, @service_price, @service_desc)", 
                SqlConnection);
            command.Parameters.AddWithValue("id_service", textBox1.Text);
            command.Parameters.AddWithValue("service_name", textBox2.Text);
            command.Parameters.AddWithValue("service_price", textBox3.Text);
            command.Parameters.AddWithValue("service_desc", richTextBox1.Text);
            command.ExecuteNonQuery().ToString();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
