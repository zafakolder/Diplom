﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormAddOrders : Form
    {
        private SqlConnection SqlConnection = null;

        public FormAddOrders()
        {
            InitializeComponent();
        }

        private void FormAddOrders_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["services"].ConnectionString);
            SqlConnection.Open();
        }

        //Добавление новой записи
        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormOrders form = new FormOrders();
            form.Show();
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand($"insert into [Orders] (order_id, id_service, service_name, id_customer, customer_organ_name) values (@order_id, @id_service, @service_name, @id_customer, @customer_organ_name)",
                SqlConnection);
            command.Parameters.AddWithValue("order_id", textBox1.Text);
            command.Parameters.AddWithValue("service_name", textBox2.Text);
            command.Parameters.AddWithValue("id_service", textBox3.Text);
            command.Parameters.AddWithValue("id_customer", textBox6.Text);
            command.Parameters.AddWithValue("customer_organ_name", richTextBox1.Text);
            command.ExecuteNonQuery().ToString();
        }
    }
}
