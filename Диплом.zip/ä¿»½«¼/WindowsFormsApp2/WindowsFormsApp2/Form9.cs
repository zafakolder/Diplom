﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormAddCustomer : Form
    {
        private SqlConnection SqlConnection = null;
        public FormAddCustomer()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormCustomers form = new FormCustomers();
            form.Show();
            this.Close();
        }

        private void FormAddCustomer_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["services"].ConnectionString);
            SqlConnection.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand($"insert into [Customers] (id_customer, customer_FIO, customer_tel, customer_email, customer_address, customer_organ_name) values (@id_customer, @customer_FIO, @customer_tel, @customer_email, @customer_address, @customer_organ_name)",
                SqlConnection);
            command.Parameters.AddWithValue("id_customer", textBox6.Text);
            command.Parameters.AddWithValue("customer_FIO", textBox5.Text);
            command.Parameters.AddWithValue("customer_tel", textBox4.Text);
            command.Parameters.AddWithValue("customer_email", textBox3.Text);
            command.Parameters.AddWithValue("customer_address", richTextBox2.Text);
            command.Parameters.AddWithValue("customer_organ_name", richTextBox1.Text);
            command.ExecuteNonQuery().ToString();
        }
    }
}
