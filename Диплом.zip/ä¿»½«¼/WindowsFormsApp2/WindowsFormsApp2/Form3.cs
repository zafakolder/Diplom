﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Deleted
    }
    public partial class FormServicesRedakt : Form
    {
        private SqlConnection SqlConnection = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private SqlCommandBuilder sqlBuilder = null;
        private DataSet ds = null;
        DataTable servicesTable;

        int selectedRow;
        public FormServicesRedakt()
        {
            InitializeComponent();
        }
      

        //Поиск по названию
        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"service_name LIKE '%{richTextBox2.Text}%'";

        }

        //Загрузка данных в DataGridView
        private void FormServicesRedakt_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Services"].ConnectionString);
            SqlConnection.Open();
            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Services", SqlConnection);
            servicesTable = new DataTable();
            sqlDataAdapter.Fill(servicesTable);
            dataGridView1.DataSource = servicesTable;
            dataGridView1.Columns[0].HeaderText = "ID";
            dataGridView1.Columns[1].HeaderText = "Название";
            dataGridView1.Columns[2].HeaderText = "Мин.Стоимость";
            dataGridView1.Columns[3].HeaderText = "Описание";
            ds = new DataSet();
            sqlDataAdapter.Fill(ds, "Services");

            dataGridView1.DataSource = ds.Tables["Services"];

            SqlCommand cmd = SqlConnection.CreateCommand();

            //LoadData();
            SqlConnection.Close();
        }

        //Чтение строки
        private void ReadSingleRow(DataGridView dataGridView, IDataRecord record)
        {
            dataGridView.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetInt32(2), record.GetString(3), RowState.ModifiedNew);

        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];

                textBox1.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                textBox3.Text = row.Cells[2].Value.ToString();
                richTextBox1.Text = row.Cells[3].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string Message;
            Message = "Вы точно желаете удалить запись?";

            if (MessageBox.Show(Message, "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                int id_service = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());
                string sql = "DELETE FROM Services WHERE id_service = @id_service";

                SqlCommand deleteRecord = new SqlCommand();
                deleteRecord.Connection = SqlConnection;
                deleteRecord.CommandType = CommandType.Text;
                deleteRecord.CommandText = sql;

                SqlParameter RowParameter = new SqlParameter();
                RowParameter.ParameterName = "@id_service";
                RowParameter.SqlDbType = SqlDbType.Int;
                RowParameter.IsNullable = false;
                RowParameter.Value = id_service;

                deleteRecord.Parameters.Add(RowParameter);

                deleteRecord.Connection.Open();

                deleteRecord.ExecuteNonQuery();

                deleteRecord.Connection.Close();

                ds.GetChanges();
                ds.Clear();
                sqlDataAdapter.Fill(servicesTable);
                
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                SqlConnection.Open();

                int id_service,  service_price;
                
                string service_name, service_desc;

                id_service = int.Parse(dataGridView1.SelectedRows[0].Cells["id_service"].Value.ToString());
                
                service_name = textBox2.Text;
                service_price = int.Parse(textBox3.Text);
                service_desc = richTextBox1.Text;



                SqlCommand command = new SqlCommand($"UPDATE Services set service_name =' " + textBox2.Text + " ', service_price =' " + textBox3.Text + " ', service_desc =' " + richTextBox1.Text + " ' where id_service =" +id_service ,
                    SqlConnection);
               
                command.ExecuteNonQuery().ToString();
                
                ds.GetChanges();
                ds.Clear();
                sqlDataAdapter.Fill(ds, "Services");
                sqlDataAdapter.Fill(servicesTable);
                
                SqlConnection.Close();
                
               
            }
        }
    }
}
