﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApp2
{
  
    public partial class FormCustomerRedakt : Form
    {
        private SqlConnection SqlConnection = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private SqlCommandBuilder sqlBuilder = null;
        private DataSet ds = null;
        DataTable CustomersTable;

        int selectedRow;
        public FormCustomerRedakt()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormCustomers form = new FormCustomers();
            form.Show();
            this.Close();
        }

        private void FormCustomerRedakt_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Services"].ConnectionString);
            SqlConnection.Open();
            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Customers", SqlConnection);
            CustomersTable = new DataTable();
            sqlDataAdapter.Fill(CustomersTable);
            dataGridView1.DataSource = CustomersTable;
            dataGridView1.Columns[0].HeaderText = "Номер заказчика";
            dataGridView1.Columns[1].HeaderText = "ФИО";
            dataGridView1.Columns[2].HeaderText = "Телефон";
            dataGridView1.Columns[3].HeaderText = "E-Mail";
            dataGridView1.Columns[4].HeaderText = "Адрес";
            dataGridView1.Columns[5].HeaderText = "Название организации";
            ds = new DataSet();
            sqlDataAdapter.Fill(ds, "Customers");

            dataGridView1.DataSource = ds.Tables["Customers"];

            SqlCommand cmd = SqlConnection.CreateCommand();

            
            SqlConnection.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"customer_FIO LIKE '%{textBox1.Text}%'";
        }
        private void ReadSingleRow(DataGridView dataGridView, IDataRecord record)
        {
            dataGridView.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetString(5), RowState.ModifiedNew);

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];

                textBox7.Text = row.Cells[0].Value.ToString();
                textBox6.Text = row.Cells[1].Value.ToString();
                textBox5.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                richTextBox1.Text = row.Cells[4].Value.ToString();
                richTextBox2.Text = row.Cells[5].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                SqlConnection.Open();

                int id_customer;

                id_customer = int.Parse(dataGridView1.SelectedRows[0].Cells["id_customer"].Value.ToString());

                SqlCommand command = new SqlCommand($"UPDATE Customers set customer_FIO =' " + textBox6.Text + " ', customer_tel =' " + textBox5.Text + " ', customer_email =' " + textBox4.Text + " ', customer_address =' " + richTextBox1.Text + " ', customer_organ_name =' " + richTextBox2.Text + " ' where id_customer =" + id_customer,
                    SqlConnection);

                command.ExecuteNonQuery().ToString();

                ds.GetChanges();
                ds.Clear();
                sqlDataAdapter.Fill(ds, "Customers");
                sqlDataAdapter.Fill(CustomersTable);

                SqlConnection.Close();


            }
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];

                textBox7.Text = row.Cells[0].Value.ToString();
                textBox6.Text = row.Cells[1].Value.ToString();
                textBox5.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                richTextBox1.Text = row.Cells[4].Value.ToString();
                richTextBox2.Text = row.Cells[5].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Message;
            Message = "Вы точно желаете удалить запись?";

            if (MessageBox.Show(Message, "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                int id_service = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());
                string sql = "DELETE FROM Customers WHERE id_customer = @id_customer";

                SqlCommand deleteRecord = new SqlCommand();
                deleteRecord.Connection = SqlConnection;
                deleteRecord.CommandType = CommandType.Text;
                deleteRecord.CommandText = sql;

                SqlParameter RowParameter = new SqlParameter();
                RowParameter.ParameterName = "@id_customer";
                RowParameter.SqlDbType = SqlDbType.Int;
                RowParameter.IsNullable = false;
                RowParameter.Value = id_service;

                deleteRecord.Parameters.Add(RowParameter);

                deleteRecord.Connection.Open();

                deleteRecord.ExecuteNonQuery();

                deleteRecord.Connection.Close();

                ds.GetChanges();
                ds.Clear();
                sqlDataAdapter.Fill(ds, "Customers");
                sqlDataAdapter.Fill(CustomersTable);

            }
        }
    }
}
