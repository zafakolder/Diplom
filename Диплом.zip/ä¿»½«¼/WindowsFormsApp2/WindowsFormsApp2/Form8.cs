﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormCustomers : Form
    {

        private SqlConnection SqlConnection = null;
        private SqlDataAdapter adapter = null;
        private SqlCommandBuilder sqlBuilder = null;
        private DataSet ds = null;
        DataTable CustomersTable;

        public FormCustomers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAddCustomer form = new FormAddCustomer();
            form.Show();
            this.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormCustomerRedakt form = new FormCustomerRedakt();
            form.Show();
            this.Close();  
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormServices form = new FormServices();
            form.Show();
            this.Close();
        }

        private void FormCustomers_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["services"].ConnectionString);
            SqlConnection.Open();
            adapter = new SqlDataAdapter("SELECT * FROM Customers", SqlConnection);
            CustomersTable = new DataTable();
            adapter.Fill(CustomersTable);
            dataGridView1.DataSource = CustomersTable;
            dataGridView1.Columns[0].HeaderText = "Номер заказчика";
            dataGridView1.Columns[1].HeaderText = "ФИО заказчика";
            dataGridView1.Columns[2].HeaderText = "Номер телефона заказчика";
            dataGridView1.Columns[3].HeaderText = "E-mail";
            dataGridView1.Columns[4].HeaderText = "Адрес";
            dataGridView1.Columns[5].HeaderText = "Название организации";
            ds = new DataSet();
            adapter.Fill(ds, "Customers");

            dataGridView1.DataSource = ds.Tables["Customers"];

            SqlCommand cmd = SqlConnection.CreateCommand();

            //LoadData();
            SqlConnection.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"customer_FIO LIKE '%{textBox1.Text}%'";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormOrders form = new FormOrders();
            form.Show();
            this.Hide();
        }
    }
}
