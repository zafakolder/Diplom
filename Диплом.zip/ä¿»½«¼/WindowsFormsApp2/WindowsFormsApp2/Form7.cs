﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormOrdersRedakt : Form
    {
        private SqlConnection SqlConnection = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private DataSet ds = null;
        DataTable OrdersTable;

        int selectedRow;

        public FormOrdersRedakt()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormOrders form = new FormOrders();
            form.Show();
            this.Close();
        }

        private void FormOrdersRedakt_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Services"].ConnectionString);
            SqlConnection.Open();
            sqlDataAdapter = new SqlDataAdapter("SELECT * FROM Orders", SqlConnection);
            OrdersTable = new DataTable();
            sqlDataAdapter.Fill(OrdersTable);
            dataGridView1.DataSource = OrdersTable;
            dataGridView1.Columns[0].HeaderText = "Номер заказа";
            dataGridView1.Columns[1].HeaderText = "Номер услуги";
            dataGridView1.Columns[2].HeaderText = "Название услуги";
            dataGridView1.Columns[3].HeaderText = "Номер заказчика";
            dataGridView1.Columns[4].HeaderText = "Название организации";
            ds = new DataSet();
            sqlDataAdapter.Fill(ds, "Orders");

            dataGridView1.DataSource = ds.Tables["Orders"];

            SqlCommand cmd = SqlConnection.CreateCommand();

            //LoadData();
            SqlConnection.Close();
        }
        //Чтение строки
        private void ReadSingleRow(DataGridView dataGridView, IDataRecord record)
        {
            dataGridView.Rows.Add(record.GetInt32(0), record.GetInt32(1), record.GetString(2), record.GetInt32(3), record.GetString(4), RowState.ModifiedNew);

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string Message;
            Message = "Вы точно желаете удалить запись?";

            if (MessageBox.Show(Message, "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                return;
            }
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridView1.SelectedRows[0].Index;

                int order_id = int.Parse(dataGridView1[0, selectedIndex].Value.ToString());
                string sql = "DELETE FROM Orders WHERE order_id = @order_id";

                SqlCommand deleteRecord = new SqlCommand();
                deleteRecord.Connection = SqlConnection;
                deleteRecord.CommandType = CommandType.Text;
                deleteRecord.CommandText = sql;

                SqlParameter RowParameter = new SqlParameter();
                RowParameter.ParameterName = "@order_id";
                RowParameter.SqlDbType = SqlDbType.Int;
                RowParameter.IsNullable = false;
                RowParameter.Value = order_id;

                deleteRecord.Parameters.Add(RowParameter);

                deleteRecord.Connection.Open();

                deleteRecord.ExecuteNonQuery();

                deleteRecord.Connection.Close();

                ds.GetChanges();
                ds.Clear();
                sqlDataAdapter.Fill(OrdersTable);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
