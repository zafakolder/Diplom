﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

namespace WindowsFormsApp2
{
    public partial class FormServices : Form
    {
        private SqlConnection SqlConnection = null;
        private SqlDataAdapter adapter = null;
        SqlCommand servicesCommand;
        SqlDataAdapter servicesAdapter;
        DataSet servicesDataset;
        DataTable servicesTable;
        

        public FormServices()
        {
            InitializeComponent();
        }

        private void FormServices_Load(object sender, EventArgs e)
        {
            SqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["services"].ConnectionString);
            SqlConnection.Open();
            adapter = new SqlDataAdapter("SELECT * FROM services", SqlConnection);
            servicesTable = new DataTable();
            adapter.Fill(servicesTable);
            dataGridView1.DataSource = servicesTable;
            dataGridView1.Refresh();
            if (SqlConnection.State == ConnectionState.Open)
            {
                MessageBox.Show("Подключение установленно");
            }
            else 
            {
                MessageBox.Show("Нет подключения");
            }
            dataGridView1.Refresh();
            dataGridView1.Columns[0].HeaderText = "ID";
            dataGridView1.Columns[1].HeaderText = "Название";
            dataGridView1.Columns[2].HeaderText = "Мин.Стоимость";
            dataGridView1.Columns[3].HeaderText = "Описание";
        }

       

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormAddServices form = new FormAddServices();
            form.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormServicesRedakt form = new FormServicesRedakt();
            form.Show();
        }

        private void dataGridView1_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            adapter = new SqlDataAdapter("SELECT * FROM services", SqlConnection);
            servicesTable = new DataTable();
            adapter.Fill(servicesTable);
            dataGridView1.DataSource = servicesTable;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"service_name LIKE '%{textBox1.Text}%'";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = "";
                    break;
                case 1:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"service_min_price <=500";
                    break;

                case 2:
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = $"service_min_price > 500 AND service_min_price <= 1000";
                    break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormCustomers form = new FormCustomers();
            form.Show();
            this.Hide();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
